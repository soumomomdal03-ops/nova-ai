package com.nova.ai.ui.screens

import android.speech.SpeechRecognizer
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.ErrorOutline
import androidx.compose.material.icons.rounded.Mic
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.nova.ai.data.AppLanguage
import com.nova.ai.data.suggestions
import com.nova.ai.ui.components.GlassCard
import com.nova.ai.ui.components.NovaOrb
import com.nova.ai.ui.components.SectionLabel
import com.nova.ai.ui.rememberMicPermission
import com.nova.ai.viewmodel.AssistantViewModel
import java.util.Calendar

private fun greeting(language: AppLanguage): String {
    val hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
    return when (language) {
        AppLanguage.HINDI -> when {
            hour < 12 -> "सुप्रभात"
            hour < 17 -> "नमस्कार"
            else -> "शुभ संध्या"
        }
        else -> when {
            hour < 12 -> "Good morning"
            hour < 17 -> "Good afternoon"
            else -> "Good evening"
        }
    }
}

@Composable
fun DashboardScreen(vm: AssistantViewModel, openVoice: () -> Unit, openChat: () -> Unit) {
    val context = LocalContext.current
    val scheme = MaterialTheme.colorScheme
    val settings by vm.settings.collectAsStateWithLifecycle()
    val orbState by vm.orbState.collectAsStateWithLifecycle()
    val level by vm.voice.level.collectAsStateWithLifecycle()
    val ttsReady by vm.voice.ttsReady.collectAsStateWithLifecycle()
    val mic = rememberMicPermission()
    val speechAvailable = remember { SpeechRecognizer.isRecognitionAvailable(context) }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 20.dp, vertical = 8.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text(greeting(settings.language), style = MaterialTheme.typography.titleMedium, color = scheme.onSurfaceVariant)
        Text("How can I help?", style = MaterialTheme.typography.headlineLarge)

        Box(Modifier.clip(CircleShape).clickable(onClick = openVoice)) {
            NovaOrb(orbSize = 220.dp, state = orbState, level = level)
        }

        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Button(onClick = openVoice, modifier = Modifier.weight(1f)) {
                Icon(Icons.Rounded.Mic, contentDescription = null)
                Spacer(Modifier.width(8.dp))
                Text("Talk")
            }
            OutlinedButton(onClick = openChat, modifier = Modifier.weight(1f)) {
                Icon(Icons.Rounded.AutoAwesome, contentDescription = null)
                Spacer(Modifier.width(8.dp))
                Text("Type")
            }
        }

        GlassCard(Modifier.fillMaxWidth()) {
            SectionLabel("System check")
            StatusRow(
                label = "Microphone",
                ok = mic.granted,
                detail = if (mic.granted) "Allowed" else "Needed for voice commands",
                action = if (mic.granted) null else "Allow" to mic.request
            )
            StatusRow(
                label = "Speech recognition",
                ok = speechAvailable,
                detail = if (speechAvailable) "Available on this phone" else "Not found. Install or update the Google app."
            )
            StatusRow(
                label = "Voice output",
                ok = ttsReady,
                detail = if (ttsReady) "Ready" else "Starting or not installed"
            )
        }

        GlassCard(Modifier.fillMaxWidth()) {
            SectionLabel("Try saying")
            suggestions(settings.language).forEach { text ->
                Text(
                    text,
                    style = MaterialTheme.typography.bodyLarge,
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .clickable {
                            vm.send(text)
                            openChat()
                        }
                        .padding(vertical = 10.dp)
                )
            }
            Text(
                "Task automation arrives in later phases. For now Nova repeats back what it heard.",
                style = MaterialTheme.typography.bodySmall,
                color = scheme.onSurfaceVariant,
                modifier = Modifier.padding(top = 8.dp)
            )
        }
    }
}

@Composable
private fun StatusRow(
    label: String,
    ok: Boolean,
    detail: String,
    action: Pair<String, () -> Unit>? = null
) {
    val scheme = MaterialTheme.colorScheme
    Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
        Icon(
            if (ok) Icons.Rounded.CheckCircle else Icons.Rounded.ErrorOutline,
            contentDescription = null,
            tint = if (ok) scheme.primary else scheme.error
        )
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(label, style = MaterialTheme.typography.bodyLarge, fontWeight = FontWeight.Medium)
            Text(detail, style = MaterialTheme.typography.bodySmall, color = scheme.onSurfaceVariant)
        }
        if (action != null) {
            TextButton(onClick = action.second) { Text(action.first) }
        }
    }
}
