package com.nova.ai.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.Bolt
import androidx.compose.material.icons.rounded.Call
import androidx.compose.material.icons.rounded.ChevronRight
import androidx.compose.material.icons.rounded.Forum
import androidx.compose.material.icons.rounded.History
import androidx.compose.material.icons.rounded.Image
import androidx.compose.material.icons.rounded.Link
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.Mic
import androidx.compose.material.icons.rounded.Movie
import androidx.compose.material.icons.rounded.Notifications
import androidx.compose.material.icons.rounded.Person
import androidx.compose.material.icons.rounded.PhotoCamera
import androidx.compose.material.icons.rounded.PlayCircle
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material.icons.rounded.VerifiedUser
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.foundation.lazy.items
import androidx.compose.ui.unit.dp
import com.nova.ai.ui.Tabs
import com.nova.ai.ui.components.GlassCard
import com.nova.ai.ui.components.SectionLabel

private data class ModuleItem(
    val title: String,
    val subtitle: String,
    val icon: ImageVector,
    val phase: Int,
    val route: String? = null
)

private val moduleItems = listOf(
    ModuleItem("AI Chat", "Type to Nova", Icons.Rounded.AutoAwesome, 1, Tabs.CHAT),
    ModuleItem("Voice Assistant", "Hold to talk or hold a conversation", Icons.Rounded.Mic, 1, Tabs.VOICE),
    ModuleItem("AI Settings", "Language, voice and theme", Icons.Rounded.Settings, 1, Tabs.SETTINGS),
    ModuleItem("Privacy & Security", "Permissions and your data", Icons.Rounded.Lock, 1, Tabs.PRIVACY),
    ModuleItem("Login & Memory", "Accounts, saved preferences, chat history", Icons.Rounded.Person, 2),
    ModuleItem("Approval Center", "Review actions before Nova does them", Icons.Rounded.VerifiedUser, 3),
    ModuleItem("Automation Center", "Open apps, reminders, alarms", Icons.Rounded.Bolt, 3),
    ModuleItem("Task History", "Everything Nova has done", Icons.Rounded.History, 3),
    ModuleItem("Smart Call Manager", "Call screening and unavailable replies", Icons.Rounded.Call, 4),
    ModuleItem("WhatsApp Manager", "Suggested replies you approve", Icons.Rounded.Notifications, 4),
    ModuleItem("Instagram Manager", "DMs, comments and captions", Icons.Rounded.PhotoCamera, 4),
    ModuleItem("Messenger Manager", "Page inbox replies", Icons.Rounded.Forum, 4),
    ModuleItem("Connected Accounts", "Google, Meta and more", Icons.Rounded.Link, 4),
    ModuleItem("YouTube Studio", "Channel dashboard and uploads", Icons.Rounded.PlayCircle, 5),
    ModuleItem("AI Video Creator", "From idea to finished video", Icons.Rounded.Movie, 5),
    ModuleItem("Image Creator", "Thumbnails and images", Icons.Rounded.Image, 5),
    ModuleItem("Internet Research", "Reports with source links", Icons.Rounded.Search, 6)
)

@Composable
fun ModulesScreen(onOpen: (String) -> Unit) {
    val scheme = MaterialTheme.colorScheme
    val grouped = moduleItems.groupBy { it.phase }

    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = androidx.compose.foundation.layout.PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            GlassCard(Modifier.fillMaxWidth()) {
                SectionLabel("Build progress")
                Text("Phase 1 of 7: interface, chat and voice", style = MaterialTheme.typography.bodyLarge)
                Spacer(Modifier.height(10.dp))
                LinearProgressIndicator(
                    progress = { 1f / 7f },
                    modifier = Modifier.fillMaxWidth(),
                    color = scheme.primary,
                    trackColor = scheme.surfaceVariant
                )
                Spacer(Modifier.height(8.dp))
                Text(
                    "Greyed-out items are planned. They unlock as each phase is built and tested.",
                    style = MaterialTheme.typography.bodySmall,
                    color = scheme.onSurfaceVariant
                )
            }
        }
        grouped.forEach { (phase, list) ->
            item {
                Text(
                    if (phase == 1) "Available now" else "Phase $phase",
                    style = MaterialTheme.typography.titleMedium,
                    color = if (phase == 1) scheme.primary else scheme.onSurfaceVariant,
                    modifier = Modifier.padding(top = 8.dp, start = 4.dp)
                )
            }
            items(list) { module ->
                val open = module.route
                GlassCard(
                    Modifier.fillMaxWidth(),
                    onClick = if (open != null) ({ onOpen(open) }) else null
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            Modifier
                                .size(44.dp)
                                .clip(CircleShape)
                                .background(scheme.primary.copy(alpha = if (open != null) 0.18f else 0.07f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                module.icon,
                                contentDescription = null,
                                tint = if (open != null) scheme.primary else scheme.onSurfaceVariant
                            )
                        }
                        Spacer(Modifier.width(14.dp))
                        Column(Modifier.weight(1f)) {
                            Text(
                                module.title,
                                style = MaterialTheme.typography.titleMedium,
                                color = if (open != null) scheme.onSurface else scheme.onSurfaceVariant
                            )
                            Text(
                                module.subtitle,
                                style = MaterialTheme.typography.bodySmall,
                                color = scheme.onSurfaceVariant
                            )
                        }
                        if (open != null) {
                            Icon(Icons.Rounded.ChevronRight, contentDescription = null, tint = scheme.onSurfaceVariant)
                        } else {
                            Text(
                                "Phase ${module.phase}",
                                style = MaterialTheme.typography.bodySmall,
                                color = scheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }
        }
    }
}
