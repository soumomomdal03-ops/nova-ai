package com.nova.ai.ui.screens

import android.content.Intent
import android.net.Uri
import android.provider.Settings
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.nova.ai.ui.components.GlassCard
import com.nova.ai.ui.components.SectionLabel
import com.nova.ai.ui.rememberMicPermission
import com.nova.ai.viewmodel.AssistantViewModel

@Composable
fun PrivacyScreen(vm: AssistantViewModel) {
    val context = LocalContext.current
    val scheme = MaterialTheme.colorScheme
    val mic = rememberMicPermission()
    val messages by vm.messages.collectAsStateWithLifecycle()
    var confirmClear by remember { mutableStateOf(false) }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        GlassCard(Modifier.fillMaxWidth()) {
            SectionLabel("Permissions")
            Text(
                if (mic.granted) "Microphone: allowed" else "Microphone: not allowed",
                style = MaterialTheme.typography.bodyLarge
            )
            Text(
                "Nova only listens while you hold the orb, press the microphone button, or run a conversation. It stops when you leave the app.",
                style = MaterialTheme.typography.bodySmall,
                color = scheme.onSurfaceVariant,
                modifier = Modifier.padding(top = 4.dp, bottom = 12.dp)
            )
            Row {
                if (!mic.granted) {
                    Button(onClick = mic.request) { Text("Allow microphone") }
                    Spacer(Modifier.width(8.dp))
                }
                OutlinedButton(onClick = {
                    val intent = Intent(
                        Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                        Uri.fromParts("package", context.packageName, null)
                    )
                    context.startActivity(intent)
                }) { Text("Open app settings") }
            }
        }

        GlassCard(Modifier.fillMaxWidth()) {
            SectionLabel("Your conversation")
            Text(
                "${messages.size} messages in this session.",
                style = MaterialTheme.typography.bodyLarge
            )
            Spacer(Modifier.height(12.dp))
            OutlinedButton(onClick = { confirmClear = true }, enabled = messages.isNotEmpty()) {
                Icon(Icons.Rounded.Delete, contentDescription = null)
                Spacer(Modifier.width(8.dp))
                Text("Clear conversation")
            }
        }

        GlassCard(Modifier.fillMaxWidth()) {
            SectionLabel("Where your data lives")
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Chat messages stay in the phone's memory and disappear when the app closes.", style = MaterialTheme.typography.bodyMedium)
                Text("Language, voice and theme choices are saved on this phone only.", style = MaterialTheme.typography.bodyMedium)
                Text("This version of Nova has no internet permission, so the app itself sends nothing anywhere.", style = MaterialTheme.typography.bodyMedium)
                Text(
                    "Speech recognition is done by Android's own speech service. Depending on your phone and language, that service may send audio to Google. Nova doesn't control that.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = scheme.onSurfaceVariant
                )
            }
        }
    }

    if (confirmClear) {
        AlertDialog(
            onDismissRequest = { confirmClear = false },
            title = { Text("Clear conversation?") },
            text = { Text("This deletes every message in this chat. It can't be undone.") },
            confirmButton = {
                TextButton(onClick = {
                    vm.clearHistory()
                    confirmClear = false
                }) { Text("Clear") }
            },
            dismissButton = { TextButton(onClick = { confirmClear = false }) { Text("Cancel") } }
        )
    }
}
