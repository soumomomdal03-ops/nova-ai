package com.nova.ai.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.slideInVertically
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.nova.ai.ui.components.NovaBackground
import com.nova.ai.ui.components.NovaOrb
import kotlinx.coroutines.delay

@Composable
fun SplashScreen(ready: Boolean, onFinished: () -> Unit) {
    val finish by rememberUpdatedState(onFinished)
    var minElapsed by remember { mutableStateOf(false) }
    var showText by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        showText = true
        delay(1800)
        minElapsed = true
    }
    LaunchedEffect(minElapsed, ready) {
        if (minElapsed && ready) finish()
    }

    NovaBackground {
        Column(
            Modifier.align(Alignment.Center),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            NovaOrb(orbSize = 180.dp)
            Spacer(Modifier.height(28.dp))
            AnimatedVisibility(
                visible = showText,
                enter = fadeIn(tween(900)) + slideInVertically(tween(900)) { it / 3 }
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        "NOVA AI",
                        style = MaterialTheme.typography.headlineLarge,
                        letterSpacing = 8.sp
                    )
                    Spacer(Modifier.height(8.dp))
                    Text(
                        "Your personal digital operator",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }
    }
}
