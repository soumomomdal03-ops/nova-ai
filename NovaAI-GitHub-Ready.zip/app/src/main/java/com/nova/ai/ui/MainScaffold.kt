package com.nova.ai.ui

import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.core.tween
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.consumeWindowInsets
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.isImeVisible
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Apps
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.Home
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.Menu
import androidx.compose.material.icons.rounded.Mic
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material3.CenterAlignedTopAppBar
import androidx.compose.material3.DrawerValue
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalDrawerSheet
import androidx.compose.material3.ModalNavigationDrawer
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.NavigationDrawerItem
import androidx.compose.material3.NavigationDrawerItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.rememberDrawerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.nova.ai.ui.components.NovaBackground
import com.nova.ai.ui.components.NovaOrb
import com.nova.ai.ui.screens.ChatScreen
import com.nova.ai.ui.screens.DashboardScreen
import com.nova.ai.ui.screens.ModulesScreen
import com.nova.ai.ui.screens.PrivacyScreen
import com.nova.ai.ui.screens.SettingsScreen
import com.nova.ai.ui.screens.VoiceScreen
import com.nova.ai.viewmodel.AssistantViewModel
import kotlinx.coroutines.launch

private data class NavItem(val route: String, val label: String, val icon: ImageVector)

private val bottomTabs = listOf(
    NavItem(Tabs.HOME, "Home", Icons.Rounded.Home),
    NavItem(Tabs.CHAT, "Chat", Icons.Rounded.AutoAwesome),
    NavItem(Tabs.VOICE, "Voice", Icons.Rounded.Mic),
    NavItem(Tabs.MODULES, "Modules", Icons.Rounded.Apps),
    NavItem(Tabs.SETTINGS, "Settings", Icons.Rounded.Settings)
)

private val drawerItems = bottomTabs + NavItem(Tabs.PRIVACY, "Privacy & Security", Icons.Rounded.Lock)

private fun titleFor(route: String): String = when (route) {
    Tabs.CHAT -> "AI Chat"
    Tabs.VOICE -> "Voice Assistant"
    Tabs.MODULES -> "Modules"
    Tabs.SETTINGS -> "AI Settings"
    Tabs.PRIVACY -> "Privacy & Security"
    else -> "NOVA AI"
}

private fun NavHostController.goTo(route: String) {
    navigate(route) {
        popUpTo(graph.findStartDestination().id) { saveState = true }
        launchSingleTop = true
        restoreState = true
    }
}

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun MainScaffold(vm: AssistantViewModel) {
    val nav = rememberNavController()
    val drawerState = rememberDrawerState(DrawerValue.Closed)
    val scope = rememberCoroutineScope()
    val snackbar = remember { SnackbarHostState() }
    val backStack by nav.currentBackStackEntryAsState()
    val route = backStack?.destination?.route ?: Tabs.HOME
    val imeVisible = WindowInsets.isImeVisible

    LaunchedEffect(Unit) { vm.notices.collect { snackbar.showSnackbar(it) } }
    // Never keep the microphone open when the app leaves the screen.
    LifecycleEventEffect(Lifecycle.Event.ON_STOP) { vm.stopAll() }

    ModalNavigationDrawer(
        drawerState = drawerState,
        drawerContent = {
            NovaDrawer(current = route) { target ->
                scope.launch { drawerState.close() }
                nav.goTo(target)
            }
        }
    ) {
        NovaBackground {
            Scaffold(
                containerColor = Color.Transparent,
                topBar = {
                    CenterAlignedTopAppBar(
                        title = { Text(titleFor(route), fontWeight = FontWeight.Medium) },
                        navigationIcon = {
                            IconButton(onClick = { scope.launch { drawerState.open() } }) {
                                Icon(Icons.Rounded.Menu, contentDescription = "Open menu")
                            }
                        },
                        colors = TopAppBarDefaults.centerAlignedTopAppBarColors(
                            containerColor = Color.Transparent,
                            scrolledContainerColor = Color.Transparent
                        )
                    )
                },
                bottomBar = { if (!imeVisible) NovaBottomBar(route) { nav.goTo(it) } },
                snackbarHost = { SnackbarHost(snackbar) }
            ) { inner ->
                NavHost(
                    navController = nav,
                    startDestination = Tabs.HOME,
                    modifier = Modifier.padding(inner).consumeWindowInsets(inner),
                    enterTransition = { fadeIn(tween(250)) },
                    exitTransition = { fadeOut(tween(150)) }
                ) {
                    composable(Tabs.HOME) {
                        DashboardScreen(
                            vm = vm,
                            openVoice = { nav.goTo(Tabs.VOICE) },
                            openChat = { nav.goTo(Tabs.CHAT) }
                        )
                    }
                    composable(Tabs.CHAT) { ChatScreen(vm) }
                    composable(Tabs.VOICE) { VoiceScreen(vm) }
                    composable(Tabs.MODULES) { ModulesScreen(onOpen = { nav.goTo(it) }) }
                    composable(Tabs.SETTINGS) { SettingsScreen(vm) }
                    composable(Tabs.PRIVACY) { PrivacyScreen(vm) }
                }
            }
        }
    }
}

@Composable
private fun NovaBottomBar(current: String, onSelect: (String) -> Unit) {
    val scheme = MaterialTheme.colorScheme
    NavigationBar(containerColor = scheme.surface.copy(alpha = 0.94f)) {
        bottomTabs.forEach { tab ->
            NavigationBarItem(
                selected = current == tab.route,
                onClick = { onSelect(tab.route) },
                icon = { Icon(tab.icon, contentDescription = tab.label) },
                label = { Text(tab.label) },
                colors = NavigationBarItemDefaults.colors(
                    selectedIconColor = scheme.primary,
                    selectedTextColor = scheme.primary,
                    indicatorColor = scheme.primary.copy(alpha = 0.16f),
                    unselectedIconColor = scheme.onSurfaceVariant,
                    unselectedTextColor = scheme.onSurfaceVariant
                )
            )
        }
    }
}

@Composable
private fun NovaDrawer(current: String, onNavigate: (String) -> Unit) {
    ModalDrawerSheet(drawerContainerColor = MaterialTheme.colorScheme.surface) {
        Column(Modifier.padding(24.dp)) {
            NovaOrb(orbSize = 72.dp)
            Spacer(Modifier.height(12.dp))
            Text("NOVA AI", style = MaterialTheme.typography.titleLarge)
            Text(
                "Phase 1 build",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        HorizontalDivider()
        Spacer(Modifier.height(8.dp))
        drawerItems.forEach { item ->
            NavigationDrawerItem(
                label = { Text(item.label) },
                icon = { Icon(item.icon, contentDescription = null) },
                selected = current == item.route,
                onClick = { onNavigate(item.route) },
                modifier = Modifier.padding(NavigationDrawerItemDefaults.ItemPadding)
            )
        }
    }
}
