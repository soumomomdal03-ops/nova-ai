package com.nova.ai.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.nova.ai.data.AppLanguage
import com.nova.ai.data.ThemeMode
import com.nova.ai.ui.components.GlassCard
import com.nova.ai.ui.components.NovaChip
import com.nova.ai.ui.components.SectionLabel
import com.nova.ai.viewmodel.AssistantViewModel

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun SettingsScreen(vm: AssistantViewModel) {
    val scheme = MaterialTheme.colorScheme
    val settings by vm.settings.collectAsStateWithLifecycle()
    val ttsReady by vm.voice.ttsReady.collectAsStateWithLifecycle()
    val voices = remember(settings.language, ttsReady) { vm.voice.voiceNames(settings.language.speechTag) }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        GlassCard(Modifier.fillMaxWidth()) {
            SectionLabel("Appearance")
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                ThemeMode.entries.forEach { mode ->
                    NovaChip(mode.label, settings.themeMode == mode) { vm.setTheme(mode) }
                }
            }
        }

        GlassCard(Modifier.fillMaxWidth()) {
            SectionLabel("Language")
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                AppLanguage.entries.forEach { lang ->
                    NovaChip(lang.label, settings.language == lang) { vm.setLanguage(lang) }
                }
            }
            Text(
                "Used for voice recognition and for Nova's spoken replies. Hinglish uses the Indian English engine.",
                style = MaterialTheme.typography.bodySmall,
                color = scheme.onSurfaceVariant,
                modifier = Modifier.padding(top = 8.dp)
            )
        }

        GlassCard(Modifier.fillMaxWidth()) {
            SectionLabel("Voice")
            if (voices.isEmpty()) {
                Text(
                    if (ttsReady) {
                        "No voices found for this language. Open Android Settings, search for Text-to-speech, and install the voice data."
                    } else {
                        "Voice engine is starting. If this stays empty, install a text-to-speech engine in Android Settings."
                    },
                    style = MaterialTheme.typography.bodyMedium,
                    color = scheme.onSurfaceVariant
                )
            } else {
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    voices.take(12).forEachIndexed { index, _ ->
                        NovaChip("Voice ${index + 1}", settings.voiceIndex == index) { vm.previewVoice(index) }
                    }
                }
                Text(
                    "Tap a voice to hear it. Android doesn't say whether a voice is male or female, so these are the voices installed on your phone. Selectable male and female cloud voices are planned for a later phase.",
                    style = MaterialTheme.typography.bodySmall,
                    color = scheme.onSurfaceVariant,
                    modifier = Modifier.padding(top = 8.dp)
                )
            }
            Row(Modifier.fillMaxWidth().padding(top = 16.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("Speak replies in chat", style = MaterialTheme.typography.bodyLarge)
                    Text(
                        "Voice conversations are always spoken.",
                        style = MaterialTheme.typography.bodySmall,
                        color = scheme.onSurfaceVariant
                    )
                }
                Switch(checked = settings.speakReplies, onCheckedChange = vm::setSpeakReplies)
            }
        }

        GlassCard(Modifier.fillMaxWidth()) {
            SectionLabel("Coming later")
            Text(
                "Wake word (\"Hey Nova\"), selectable cloud voices, memory controls and AI provider choice are planned for later phases.",
                style = MaterialTheme.typography.bodyMedium,
                color = scheme.onSurfaceVariant
            )
        }
    }
}
