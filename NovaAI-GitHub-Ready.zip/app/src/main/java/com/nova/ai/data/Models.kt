package com.nova.ai.data

import java.util.UUID

enum class Role { USER, NOVA }

data class ChatMessage(
    val id: String = UUID.randomUUID().toString(),
    val role: Role,
    val text: String,
    val timestamp: Long = System.currentTimeMillis(),
    val spoken: Boolean = false
)

/** Languages Nova listens and speaks in. Hinglish uses the Indian-English engines. */
enum class AppLanguage(val label: String, val speechTag: String, val sample: String) {
    ENGLISH("English", "en-IN", "Hello, I am Nova. How can I help you?"),
    HINDI("हिन्दी", "hi-IN", "नमस्ते, मैं नोवा हूँ। मैं आपकी कैसे मदद कर सकती हूँ?"),
    HINGLISH("Hinglish", "en-IN", "Hello, main Nova hoon. Bataiye, kya karna hai?")
}

enum class ThemeMode(val label: String) { SYSTEM("System"), LIGHT("Light"), DARK("Dark") }

data class NovaSettings(
    val loaded: Boolean = false,
    val language: AppLanguage = AppLanguage.ENGLISH,
    val themeMode: ThemeMode = ThemeMode.DARK,
    val voiceIndex: Int = 0,
    val speakReplies: Boolean = true,
    val onboardingDone: Boolean = false
)

fun suggestions(language: AppLanguage): List<String> = when (language) {
    AppLanguage.ENGLISH -> listOf(
        "Open YouTube and check my latest video",
        "Create a 5-minute video about space exploration",
        "Reply to my WhatsApp messages politely"
    )
    AppLanguage.HINDI -> listOf(
        "YouTube खोलो और मेरा नया वीडियो दिखाओ",
        "अंतरिक्ष खोज पर 5 मिनट का वीडियो बनाओ",
        "मेरे WhatsApp संदेशों का शिष्टता से जवाब दो"
    )
    AppLanguage.HINGLISH -> listOf(
        "YouTube kholo aur mera latest video dikhao",
        "Space exploration par 5 minute ka video banao",
        "Mere WhatsApp messages ka politely reply do"
    )
}
