package com.nova.ai.data

/**
 * The seam where Nova's brain plugs in. Phase 2 adds a provider that calls Gemini through a
 * secure Firebase Cloud Function (no API key ever lives inside the app).
 */
interface AiProvider {
    suspend fun reply(history: List<ChatMessage>, language: AppLanguage): String
}

/** Phase 1 provider: honest about the fact that no AI backend is connected yet. */
class PendingBackendAiProvider : AiProvider {
    override suspend fun reply(history: List<ChatMessage>, language: AppLanguage): String {
        val last = history.lastOrNull { it.role == Role.USER }?.text.orEmpty()
        return when (language) {
            AppLanguage.ENGLISH ->
                "I heard: “$last”. My AI brain (Gemini) connects in Phase 2, so I can't answer questions or run tasks yet. Chat, voice input and voice output are working."
            AppLanguage.HINDI ->
                "मैंने सुना: “$last”। मेरा AI दिमाग़ (Gemini) चरण 2 में जुड़ेगा, इसलिए अभी जवाब देना या काम करना संभव नहीं है। चैट और आवाज़ काम कर रही हैं।"
            AppLanguage.HINGLISH ->
                "Maine suna: “$last”. Mera AI brain (Gemini) Phase 2 mein connect hoga, isliye abhi answers ya tasks possible nahi hain. Chat aur voice kaam kar rahe hain."
        }
    }
}
