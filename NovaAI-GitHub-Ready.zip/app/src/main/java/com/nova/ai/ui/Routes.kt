package com.nova.ai.ui

/** Top-level screens (before the main app shell). */
object Routes {
    const val SPLASH = "splash"
    const val ONBOARDING = "onboarding"
    const val LOGIN = "login"
    const val MAIN = "main"
}

/** Screens inside the main shell (bottom bar + drawer). */
object Tabs {
    const val HOME = "home"
    const val CHAT = "chat"
    const val VOICE = "voice"
    const val MODULES = "modules"
    const val SETTINGS = "settings"
    const val PRIVACY = "privacy"
}
