package com.nova.ai.voice

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.speech.tts.Voice
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.Locale

enum class VoiceState { Idle, Listening, Thinking, Speaking }

/**
 * Wraps Android's built-in speech recognition (voice -> text) and text-to-speech (text -> voice).
 * Must be created and used on the main thread.
 */
class VoiceController(context: Context) {
    private val appContext = context.applicationContext
    private val main = Handler(Looper.getMainLooper())

    private val _state = MutableStateFlow(VoiceState.Idle)
    val state: StateFlow<VoiceState> = _state.asStateFlow()

    private val _partial = MutableStateFlow("")
    val partial: StateFlow<String> = _partial.asStateFlow()

    private val _level = MutableStateFlow(0f)
    val level: StateFlow<Float> = _level.asStateFlow()

    private val _ttsReady = MutableStateFlow(false)
    val ttsReady: StateFlow<Boolean> = _ttsReady.asStateFlow()

    private var recognizer: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private var pendingDone: (() -> Unit)? = null

    init {
        tts = TextToSpeech(appContext) { status ->
            if (status == TextToSpeech.SUCCESS) {
                tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(utteranceId: String?) {}

                    override fun onDone(utteranceId: String?) {
                        main.post { finishSpeaking() }
                    }

                    @Deprecated("Deprecated in Java")
                    override fun onError(utteranceId: String?) {
                        main.post { finishSpeaking() }
                    }

                    override fun onError(utteranceId: String?, errorCode: Int) {
                        main.post { finishSpeaking() }
                    }
                })
                _ttsReady.value = true
            }
        }
    }

    // ---------- Speech recognition (voice -> text) ----------

    fun isRecognitionAvailable(): Boolean = SpeechRecognizer.isRecognitionAvailable(appContext)

    fun startListening(
        languageTag: String,
        onFinal: (String) -> Unit,
        onFailure: (String) -> Unit
    ) {
        if (!isRecognitionAvailable()) {
            onFailure("Speech recognition isn't available on this phone. Install or update the Google app.")
            return
        }
        stopSpeaking()
        stopRecognizer()

        val r = SpeechRecognizer.createSpeechRecognizer(appContext)
        recognizer = r
        r.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {
                _state.value = VoiceState.Listening
            }

            override fun onBeginningOfSpeech() {}

            override fun onRmsChanged(rmsdB: Float) {
                _level.value = ((rmsdB + 2f) / 12f).coerceIn(0f, 1f)
            }

            override fun onBufferReceived(buffer: ByteArray?) {}

            override fun onEndOfSpeech() {}

            override fun onError(error: Int) {
                resetListeningUi()
                when (error) {
                    SpeechRecognizer.ERROR_CLIENT -> Unit // we cancelled it ourselves
                    SpeechRecognizer.ERROR_NO_MATCH,
                    SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> onFailure("I didn't catch that. Try again.")
                    SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS ->
                        onFailure("Microphone permission is needed for voice.")
                    SpeechRecognizer.ERROR_NETWORK,
                    SpeechRecognizer.ERROR_NETWORK_TIMEOUT ->
                        onFailure("This language needs an internet connection for speech recognition.")
                    else -> onFailure("Speech recognition error ($error).")
                }
            }

            override fun onResults(results: Bundle?) {
                val text = results
                    ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    ?.firstOrNull()
                    ?.trim()
                    .orEmpty()
                resetListeningUi()
                if (text.isEmpty()) onFailure("I didn't catch that. Try again.") else onFinal(text)
            }

            override fun onPartialResults(partialResults: Bundle?) {
                val text = partialResults
                    ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    ?.firstOrNull()
                    .orEmpty()
                if (text.isNotEmpty()) _partial.value = text
            }

            override fun onEvent(eventType: Int, params: Bundle?) {}
        })

        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, languageTag)
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
        }
        _partial.value = ""
        r.startListening(intent)
    }

    /** Push-to-talk release: finish listening and deliver what was heard. */
    fun stopListening() {
        recognizer?.stopListening()
    }

    /** Abort listening without delivering anything. */
    fun cancelListening() {
        stopRecognizer()
    }

    private fun stopRecognizer() {
        recognizer?.let {
            it.cancel()
            it.destroy()
        }
        recognizer = null
        resetListeningUi()
    }

    private fun resetListeningUi() {
        _level.value = 0f
        _partial.value = ""
        if (_state.value == VoiceState.Listening) _state.value = VoiceState.Idle
    }

    // ---------- Text-to-speech (text -> voice) ----------

    /** Names of the installed voices for a language. Android doesn't say which are male or female. */
    fun voiceNames(languageTag: String): List<String> =
        voicesFor(Locale.forLanguageTag(languageTag)).map { it.name }

    private fun voicesFor(locale: Locale): List<Voice> {
        val engine = tts ?: return emptyList()
        val all = try {
            engine.voices
        } catch (e: Exception) {
            null
        } ?: return emptyList()
        return all
            .filter { it.locale.language == locale.language && !it.features.contains("notInstalled") }
            .sortedWith(compareByDescending<Voice> { it.locale == locale }.thenBy { it.name })
    }

    fun speak(text: String, languageTag: String, voiceIndex: Int, onDone: () -> Unit = {}) {
        val engine = tts
        if (engine == null || !_ttsReady.value) {
            onDone()
            return
        }
        stopRecognizer()
        val locale = Locale.forLanguageTag(languageTag)
        engine.setLanguage(locale)
        val voices = voicesFor(locale)
        if (voices.isNotEmpty()) {
            engine.setVoice(voices[voiceIndex.coerceIn(0, voices.lastIndex)])
        }
        pendingDone = onDone
        _state.value = VoiceState.Speaking
        val clean = text.take(TextToSpeech.getMaxSpeechInputLength() - 1)
        val result = engine.speak(clean, TextToSpeech.QUEUE_FLUSH, null, "nova-utterance")
        if (result == TextToSpeech.ERROR) finishSpeaking()
    }

    fun stopSpeaking() {
        pendingDone = null
        tts?.stop()
        if (_state.value == VoiceState.Speaking) _state.value = VoiceState.Idle
    }

    private fun finishSpeaking() {
        val callback = pendingDone
        pendingDone = null
        if (_state.value == VoiceState.Speaking) _state.value = VoiceState.Idle
        callback?.invoke()
    }

    fun release() {
        stopRecognizer()
        pendingDone = null
        tts?.stop()
        tts?.shutdown()
        tts = null
    }
}
