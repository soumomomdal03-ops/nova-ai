package com.nova.ai.data

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.emptyPreferences
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map
import java.io.IOException

private val Context.novaDataStore: DataStore<Preferences> by preferencesDataStore(name = "nova_settings")

private inline fun <reified T : Enum<T>> String?.toEnum(default: T): T =
    this?.let { s -> enumValues<T>().firstOrNull { it.name == s } } ?: default

/** Stores the user's choices on the phone (language, voice, theme, onboarding). */
class SettingsStore(context: Context) {
    private val store = context.applicationContext.novaDataStore

    private object Keys {
        val language = stringPreferencesKey("language")
        val theme = stringPreferencesKey("theme")
        val voiceIndex = intPreferencesKey("voice_index")
        val speakReplies = booleanPreferencesKey("speak_replies")
        val onboardingDone = booleanPreferencesKey("onboarding_done")
    }

    val settings: Flow<NovaSettings> = store.data
        .catch { if (it is IOException) emit(emptyPreferences()) else throw it }
        .map { p ->
            NovaSettings(
                loaded = true,
                language = p[Keys.language].toEnum(AppLanguage.ENGLISH),
                themeMode = p[Keys.theme].toEnum(ThemeMode.DARK),
                voiceIndex = p[Keys.voiceIndex] ?: 0,
                speakReplies = p[Keys.speakReplies] ?: true,
                onboardingDone = p[Keys.onboardingDone] ?: false
            )
        }

    suspend fun setLanguage(value: AppLanguage) {
        store.edit { it[Keys.language] = value.name; it[Keys.voiceIndex] = 0 }
    }

    suspend fun setTheme(value: ThemeMode) {
        store.edit { it[Keys.theme] = value.name }
    }

    suspend fun setVoiceIndex(value: Int) {
        store.edit { it[Keys.voiceIndex] = value }
    }

    suspend fun setSpeakReplies(value: Boolean) {
        store.edit { it[Keys.speakReplies] = value }
    }

    suspend fun setOnboardingDone() {
        store.edit { it[Keys.onboardingDone] = true }
    }
}
