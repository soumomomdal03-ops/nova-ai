package com.nova.ai.ui.screens

import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.GraphicEq
import androidx.compose.material.icons.rounded.Stop
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.nova.ai.data.Role
import com.nova.ai.ui.components.GlassCard
import com.nova.ai.ui.components.NovaOrb
import com.nova.ai.ui.rememberMicPermission
import com.nova.ai.viewmodel.AssistantViewModel
import com.nova.ai.voice.VoiceState

@Composable
fun VoiceScreen(vm: AssistantViewModel) {
    val scheme = MaterialTheme.colorScheme
    val state by vm.orbState.collectAsStateWithLifecycle()
    val level by vm.voice.level.collectAsStateWithLifecycle()
    val partial by vm.voice.partial.collectAsStateWithLifecycle()
    val messages by vm.messages.collectAsStateWithLifecycle()
    val active by vm.conversationActive.collectAsStateWithLifecycle()
    val settings by vm.settings.collectAsStateWithLifecycle()
    val mic = rememberMicPermission()

    val lastYou = messages.lastOrNull { it.role == Role.USER }?.text
    val lastNova = messages.lastOrNull { it.role == Role.NOVA }?.text

    val status = when (state) {
        VoiceState.Listening -> "Listening…"
        VoiceState.Thinking -> "Thinking…"
        VoiceState.Speaking -> "Speaking…"
        VoiceState.Idle -> when {
            !mic.granted -> "Tap the orb to allow the microphone"
            active -> "Conversation on"
            else -> "Hold the orb and speak"
        }
    }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            "Language: ${settings.language.label} (${settings.language.speechTag})",
            style = MaterialTheme.typography.labelLarge,
            color = scheme.primary
        )
        Spacer(Modifier.height(12.dp))

        // Push-to-talk: press and hold the orb, release to send.
        Box(
            Modifier
                .size(280.dp)
                .clip(CircleShape)
                .pointerInput(mic.granted) {
                    detectTapGestures(
                        onPress = {
                            if (mic.granted) {
                                vm.startListening()
                                tryAwaitRelease()
                                vm.stopListening()
                            } else {
                                mic.request()
                            }
                        }
                    )
                },
            contentAlignment = Alignment.Center
        ) {
            NovaOrb(orbSize = 260.dp, state = state, level = level)
        }

        Text(status, style = MaterialTheme.typography.titleMedium)
        Spacer(Modifier.height(16.dp))

        val heard = if (state == VoiceState.Listening && partial.isNotEmpty()) partial else lastYou
        if (heard != null) {
            Text(
                "You: $heard",
                style = MaterialTheme.typography.bodyLarge,
                color = scheme.onSurfaceVariant,
                textAlign = TextAlign.Center
            )
            Spacer(Modifier.height(12.dp))
        }
        if (lastNova != null) {
            GlassCard(Modifier.fillMaxWidth()) {
                Text(lastNova, style = MaterialTheme.typography.bodyLarge)
            }
            Spacer(Modifier.height(16.dp))
        }

        Button(
            onClick = { if (mic.granted) vm.toggleConversation() else mic.request() },
            modifier = Modifier.fillMaxWidth().height(52.dp)
        ) {
            Icon(if (active) Icons.Rounded.Stop else Icons.Rounded.GraphicEq, contentDescription = null)
            Spacer(Modifier.width(8.dp))
            Text(if (active) "End conversation" else "Start continuous conversation")
        }
        if (state == VoiceState.Speaking) {
            Spacer(Modifier.height(8.dp))
            OutlinedButton(onClick = vm::stopAll, modifier = Modifier.fillMaxWidth()) {
                Text("Stop speaking")
            }
        }
        Text(
            "Nova answers aloud, then listens again until you end the conversation.",
            style = MaterialTheme.typography.bodySmall,
            color = scheme.onSurfaceVariant,
            textAlign = TextAlign.Center,
            modifier = Modifier.padding(top = 12.dp)
        )
    }
}
