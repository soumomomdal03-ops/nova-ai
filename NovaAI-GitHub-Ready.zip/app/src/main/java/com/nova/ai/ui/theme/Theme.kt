package com.nova.ai.ui.theme

import android.app.Activity
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp
import androidx.core.view.WindowCompat
import com.nova.ai.data.ThemeMode

val Emerald300 = Color(0xFF6EE7B7)
val Emerald400 = Color(0xFF34D399)
val Emerald500 = Color(0xFF10B981)
val Emerald700 = Color(0xFF047857)
val Emerald900 = Color(0xFF064E3B)

private val DarkScheme = darkColorScheme(
    primary = Emerald400,
    onPrimary = Color(0xFF03160E),
    primaryContainer = Emerald900,
    onPrimaryContainer = Emerald300,
    secondary = Emerald300,
    onSecondary = Color(0xFF03160E),
    background = Color(0xFF040706),
    onBackground = Color(0xFFE6F4EC),
    surface = Color(0xFF0B1210),
    onSurface = Color(0xFFE6F4EC),
    surfaceVariant = Color(0xFF16221D),
    onSurfaceVariant = Color(0xFF9DB8AA),
    outline = Color(0xFF2B3D35),
    outlineVariant = Color(0xFF1C2B25),
    error = Color(0xFFFF6B6B)
)

private val LightScheme = lightColorScheme(
    primary = Emerald700,
    onPrimary = Color.White,
    primaryContainer = Color(0xFFC9F5DF),
    onPrimaryContainer = Color(0xFF022C1F),
    secondary = Emerald500,
    onSecondary = Color.White,
    background = Color(0xFFF3FAF6),
    onBackground = Color(0xFF0A1A12),
    surface = Color.White,
    onSurface = Color(0xFF0A1A12),
    surfaceVariant = Color(0xFFE1F0E8),
    onSurfaceVariant = Color(0xFF44594E),
    outline = Color(0xFF9DB8AA),
    outlineVariant = Color(0xFFCFE3D8),
    error = Color(0xFFB3261E)
)

private val NovaTypography = Typography(
    headlineLarge = TextStyle(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.Light, fontSize = 34.sp, lineHeight = 40.sp),
    headlineMedium = TextStyle(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.Light, fontSize = 28.sp, lineHeight = 34.sp),
    titleLarge = TextStyle(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.Medium, fontSize = 20.sp),
    titleMedium = TextStyle(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.Medium, fontSize = 16.sp, letterSpacing = 0.2.sp),
    bodyLarge = TextStyle(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.Normal, fontSize = 16.sp, lineHeight = 24.sp),
    bodyMedium = TextStyle(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.Normal, fontSize = 14.sp, lineHeight = 20.sp),
    bodySmall = TextStyle(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.Normal, fontSize = 12.sp, lineHeight = 17.sp),
    labelLarge = TextStyle(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.Medium, fontSize = 14.sp, letterSpacing = 0.3.sp)
)

@Composable
fun NovaTheme(themeMode: ThemeMode, content: @Composable () -> Unit) {
    val dark = when (themeMode) {
        ThemeMode.SYSTEM -> isSystemInDarkTheme()
        ThemeMode.LIGHT -> false
        ThemeMode.DARK -> true
    }
    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as Activity).window
            val controller = WindowCompat.getInsetsController(window, view)
            controller.isAppearanceLightStatusBars = !dark
            controller.isAppearanceLightNavigationBars = !dark
        }
    }
    MaterialTheme(
        colorScheme = if (dark) DarkScheme else LightScheme,
        typography = NovaTypography,
        content = content
    )
}
