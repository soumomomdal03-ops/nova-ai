package com.nova.ai.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.nova.ai.data.AiProvider
import com.nova.ai.data.AppLanguage
import com.nova.ai.data.ChatMessage
import com.nova.ai.data.NovaSettings
import com.nova.ai.data.PendingBackendAiProvider
import com.nova.ai.data.Role
import com.nova.ai.data.SettingsStore
import com.nova.ai.data.ThemeMode
import com.nova.ai.voice.VoiceController
import com.nova.ai.voice.VoiceState
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

/** One ViewModel shared by the whole app in Phase 1: chat, voice and settings. */
class AssistantViewModel(app: Application) : AndroidViewModel(app) {
    private val store = SettingsStore(app)
    private val ai: AiProvider = PendingBackendAiProvider()
    val voice = VoiceController(app)

    val settings: StateFlow<NovaSettings> =
        store.settings.stateIn(viewModelScope, SharingStarted.Eagerly, NovaSettings())

    private val _messages = MutableStateFlow<List<ChatMessage>>(emptyList())
    val messages: StateFlow<List<ChatMessage>> = _messages.asStateFlow()

    private val _thinking = MutableStateFlow(false)
    val thinking: StateFlow<Boolean> = _thinking.asStateFlow()

    private val _conversationActive = MutableStateFlow(false)
    val conversationActive: StateFlow<Boolean> = _conversationActive.asStateFlow()

    private val _notices = MutableSharedFlow<String>(extraBufferCapacity = 4)
    val notices: SharedFlow<String> = _notices.asSharedFlow()

    private var replyJob: Job? = null

    /** What the orb should show: listening / thinking / speaking / idle. */
    val orbState: StateFlow<VoiceState> =
        combine(voice.state, _thinking) { v, t ->
            if (t && v == VoiceState.Idle) VoiceState.Thinking else v
        }.stateIn(viewModelScope, SharingStarted.Eagerly, VoiceState.Idle)

    // ---------- Chat ----------

    fun send(text: String, spoken: Boolean = false) {
        val clean = text.trim()
        if (clean.isEmpty() || _thinking.value) return
        _messages.update { it + ChatMessage(role = Role.USER, text = clean, spoken = spoken) }
        _thinking.value = true
        replyJob = viewModelScope.launch {
            val reply = try {
                ai.reply(_messages.value, settings.value.language)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                "Sorry, something went wrong: ${e.message ?: "unknown error"}"
            }
            _messages.update { it + ChatMessage(role = Role.NOVA, text = reply) }
            _thinking.value = false
            if (spoken || settings.value.speakReplies) {
                val s = settings.value
                voice.speak(reply, s.language.speechTag, s.voiceIndex) {
                    if (_conversationActive.value) listenOnce()
                }
            }
        }
    }

    fun clearHistory() {
        replyJob?.cancel()
        _thinking.value = false
        _messages.value = emptyList()
        stopAll()
    }

    // ---------- Voice ----------

    private fun listenOnce() {
        voice.startListening(
            languageTag = settings.value.language.speechTag,
            onFinal = { text -> send(text, spoken = true) },
            onFailure = { message ->
                _notices.tryEmit(message)
                _conversationActive.value = false
            }
        )
    }

    /** Push-to-talk: called when the orb is pressed. */
    fun startListening() = listenOnce()

    /** Push-to-talk: called when the orb is released. */
    fun stopListening() = voice.stopListening()

    /** Continuous conversation: listen, answer aloud, listen again. */
    fun toggleConversation() {
        if (_conversationActive.value) {
            stopAll()
        } else {
            _conversationActive.value = true
            listenOnce()
        }
    }

    fun stopAll() {
        _conversationActive.value = false
        voice.stopSpeaking()
        voice.cancelListening()
    }

    // ---------- Settings ----------

    fun setLanguage(language: AppLanguage) {
        viewModelScope.launch { store.setLanguage(language) }
    }

    fun setTheme(mode: ThemeMode) {
        viewModelScope.launch { store.setTheme(mode) }
    }

    fun setSpeakReplies(enabled: Boolean) {
        viewModelScope.launch { store.setSpeakReplies(enabled) }
    }

    fun previewVoice(index: Int) {
        viewModelScope.launch { store.setVoiceIndex(index) }
        val language = settings.value.language
        voice.speak(language.sample, language.speechTag, index)
    }

    fun completeOnboarding() {
        viewModelScope.launch { store.setOnboardingDone() }
    }

    override fun onCleared() {
        voice.release()
        super.onCleared()
    }
}
