package com.nova.ai.ui.components

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.nova.ai.ui.theme.Emerald300
import com.nova.ai.ui.theme.Emerald400
import com.nova.ai.ui.theme.Emerald500
import com.nova.ai.ui.theme.Emerald900
import com.nova.ai.voice.VoiceState

/** Full-screen background: theme colour with two soft emerald glows. */
@Composable
fun NovaBackground(modifier: Modifier = Modifier, content: @Composable BoxScope.() -> Unit) {
    val bg = MaterialTheme.colorScheme.background
    val glow = MaterialTheme.colorScheme.primary
    Box(
        modifier
            .fillMaxSize()
            .background(bg)
            .drawBehind {
                val topRight = Offset(size.width * 0.9f, size.height * 0.02f)
                drawCircle(
                    brush = Brush.radialGradient(
                        listOf(glow.copy(alpha = 0.20f), Color.Transparent),
                        center = topRight,
                        radius = size.width * 0.9f
                    ),
                    radius = size.width * 0.9f,
                    center = topRight
                )
                val bottomLeft = Offset(size.width * 0.05f, size.height * 0.98f)
                drawCircle(
                    brush = Brush.radialGradient(
                        listOf(glow.copy(alpha = 0.10f), Color.Transparent),
                        center = bottomLeft,
                        radius = size.width * 0.8f
                    ),
                    radius = size.width * 0.8f,
                    center = bottomLeft
                )
            },
        content = content
    )
}

/** Translucent card with a thin emerald edge (the "glass" look). */
@Composable
fun GlassCard(
    modifier: Modifier = Modifier,
    onClick: (() -> Unit)? = null,
    content: @Composable ColumnScope.() -> Unit
) {
    val scheme = MaterialTheme.colorScheme
    val shape = RoundedCornerShape(24.dp)
    var m = modifier
        .clip(shape)
        .background(
            Brush.linearGradient(
                listOf(scheme.surface.copy(alpha = 0.80f), scheme.surface.copy(alpha = 0.50f))
            )
        )
        .border(
            1.dp,
            Brush.linearGradient(listOf(scheme.primary.copy(alpha = 0.45f), scheme.outlineVariant.copy(alpha = 0.3f))),
            shape
        )
    if (onClick != null) m = m.clickable(onClick = onClick)
    Column(m.padding(16.dp), content = content)
}

@Composable
fun SectionLabel(text: String, modifier: Modifier = Modifier) {
    Text(
        text,
        modifier = modifier.padding(bottom = 8.dp),
        style = MaterialTheme.typography.titleMedium,
        color = MaterialTheme.colorScheme.primary
    )
}

@Composable
fun NovaChip(label: String, selected: Boolean, onClick: () -> Unit) {
    val scheme = MaterialTheme.colorScheme
    FilterChip(
        selected = selected,
        onClick = onClick,
        label = { Text(label) },
        colors = FilterChipDefaults.filterChipColors(
            selectedContainerColor = scheme.primary.copy(alpha = 0.18f),
            selectedLabelColor = scheme.primary
        )
    )
}

/** The glowing Nova orb. Speed and size react to the voice state and microphone level. */
@Composable
fun NovaOrb(
    modifier: Modifier = Modifier,
    orbSize: Dp = 200.dp,
    state: VoiceState = VoiceState.Idle,
    level: Float = 0f
) {
    val transition = rememberInfiniteTransition(label = "orb")
    val pulseMs = when (state) {
        VoiceState.Idle -> 3200
        VoiceState.Listening -> 1200
        VoiceState.Thinking -> 800
        VoiceState.Speaking -> 1000
    }
    val pulse by transition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(pulseMs, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "pulse"
    )
    val spin by transition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            tween(if (state == VoiceState.Thinking) 2500 else 9000, easing = LinearEasing)
        ),
        label = "spin"
    )
    val smoothLevel by animateFloatAsState(targetValue = level, animationSpec = tween(120), label = "level")

    Canvas(modifier.size(orbSize)) {
        val r = this.size.minDimension / 2f
        val c = center
        val bodyR = r * (0.52f + 0.04f * pulse + 0.14f * smoothLevel)

        // soft outer glow
        drawCircle(
            brush = Brush.radialGradient(listOf(Emerald500.copy(alpha = 0.40f), Color.Transparent), center = c, radius = r),
            radius = r,
            center = c
        )
        // glowing body
        drawCircle(
            brush = Brush.radialGradient(
                listOf(Emerald300, Emerald500, Emerald900),
                center = Offset(c.x - bodyR * 0.25f, c.y - bodyR * 0.3f),
                radius = bodyR * 1.3f
            ),
            radius = bodyR,
            center = c
        )
        // orbiting ring
        rotate(degrees = spin, pivot = c) {
            drawCircle(
                brush = Brush.sweepGradient(
                    listOf(Color.Transparent, Emerald400, Color.White.copy(alpha = 0.9f)),
                    center = c
                ),
                radius = r * 0.78f,
                center = c,
                style = Stroke(width = 3.dp.toPx(), cap = StrokeCap.Round)
            )
        }
    }
}
