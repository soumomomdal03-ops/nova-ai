package com.nova.ai.ui

import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.core.tween
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.nova.ai.ui.screens.LoginScreen
import com.nova.ai.ui.screens.OnboardingScreen
import com.nova.ai.ui.screens.SplashScreen
import com.nova.ai.ui.theme.NovaTheme
import com.nova.ai.viewmodel.AssistantViewModel

@Composable
fun NovaApp(vm: AssistantViewModel = viewModel()) {
    val settings by vm.settings.collectAsStateWithLifecycle()

    NovaTheme(themeMode = settings.themeMode) {
        val nav = rememberNavController()
        NavHost(
            navController = nav,
            startDestination = Routes.SPLASH,
            enterTransition = { fadeIn(tween(350)) },
            exitTransition = { fadeOut(tween(250)) }
        ) {
            composable(Routes.SPLASH) {
                SplashScreen(ready = settings.loaded) {
                    val next = if (settings.onboardingDone) Routes.MAIN else Routes.ONBOARDING
                    nav.navigate(next) { popUpTo(Routes.SPLASH) { inclusive = true } }
                }
            }
            composable(Routes.ONBOARDING) {
                OnboardingScreen(
                    selected = settings.language,
                    onLanguage = vm::setLanguage,
                    onFinish = {
                        vm.completeOnboarding()
                        nav.navigate(Routes.LOGIN) { popUpTo(Routes.ONBOARDING) { inclusive = true } }
                    }
                )
            }
            composable(Routes.LOGIN) {
                LoginScreen(
                    onGuest = { nav.navigate(Routes.MAIN) { popUpTo(Routes.LOGIN) { inclusive = true } } }
                )
            }
            composable(Routes.MAIN) { MainScaffold(vm) }
        }
    }
}
