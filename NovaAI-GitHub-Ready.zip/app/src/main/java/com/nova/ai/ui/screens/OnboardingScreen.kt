package com.nova.ai.ui.screens

import androidx.compose.animation.core.animateDpAsState
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Language
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.nova.ai.data.AppLanguage
import com.nova.ai.ui.components.NovaBackground
import com.nova.ai.ui.components.NovaChip
import com.nova.ai.ui.components.NovaOrb
import kotlinx.coroutines.launch

private data class OnboardPage(val title: String, val body: String)

private val onboardPages = listOf(
    OnboardPage(
        "Meet Nova",
        "A personal AI operator that understands what you say, plans the steps, and asks before it does anything important."
    ),
    OnboardPage(
        "Speak your language",
        "Talk or type in Hindi, English or Hinglish. Choose how Nova listens and replies."
    ),
    OnboardPage(
        "You stay in control",
        "Nova will always ask before sending, publishing or changing anything. You can review and clear your data at any time."
    )
)

@OptIn(ExperimentalLayoutApi::class, ExperimentalFoundationApi::class)
@Composable
fun OnboardingScreen(
    selected: AppLanguage,
    onLanguage: (AppLanguage) -> Unit,
    onFinish: () -> Unit
) {
    val scheme = MaterialTheme.colorScheme
    val pagerState = rememberPagerState(pageCount = { onboardPages.size })
    val scope = rememberCoroutineScope()
    val isLast = pagerState.currentPage == onboardPages.lastIndex

    NovaBackground {
        Column(Modifier.fillMaxSize().systemBarsPadding().padding(24.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                TextButton(onClick = onFinish) { Text("Skip") }
            }

            HorizontalPager(state = pagerState, modifier = Modifier.weight(1f)) { page ->
                Column(
                    Modifier.fillMaxSize(),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    when (page) {
                        0 -> NovaOrb(orbSize = 200.dp)
                        1 -> Icon(Icons.Rounded.Language, contentDescription = null, modifier = Modifier.size(96.dp), tint = scheme.primary)
                        else -> Icon(Icons.Rounded.Lock, contentDescription = null, modifier = Modifier.size(96.dp), tint = scheme.primary)
                    }
                    Spacer(Modifier.height(32.dp))
                    Text(onboardPages[page].title, style = MaterialTheme.typography.headlineMedium, textAlign = TextAlign.Center)
                    Spacer(Modifier.height(12.dp))
                    Text(
                        onboardPages[page].body,
                        style = MaterialTheme.typography.bodyLarge,
                        color = scheme.onSurfaceVariant,
                        textAlign = TextAlign.Center
                    )
                    if (page == 1) {
                        Spacer(Modifier.height(24.dp))
                        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp, Alignment.CenterHorizontally)) {
                            AppLanguage.entries.forEach { lang ->
                                NovaChip(lang.label, selected == lang) { onLanguage(lang) }
                            }
                        }
                    }
                }
            }

            Row(
                Modifier.fillMaxWidth().padding(vertical = 16.dp),
                horizontalArrangement = Arrangement.Center
            ) {
                repeat(onboardPages.size) { index ->
                    val active = index == pagerState.currentPage
                    val dotWidth by animateDpAsState(if (active) 24.dp else 8.dp, label = "dot")
                    Box(
                        Modifier
                            .padding(4.dp)
                            .height(8.dp)
                            .width(dotWidth)
                            .clip(CircleShape)
                            .background(if (active) scheme.primary else scheme.outline)
                    )
                }
            }

            Button(
                onClick = {
                    if (isLast) onFinish()
                    else scope.launch { pagerState.animateScrollToPage(pagerState.currentPage + 1) }
                },
                modifier = Modifier.fillMaxWidth().height(56.dp)
            ) {
                Text(if (isLast) "Get started" else "Next")
            }
        }
    }
}
