package com.nova.ai.ui.screens

import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.StartOffset
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.Send
import androidx.compose.material.icons.rounded.Mic
import androidx.compose.material.icons.rounded.Stop
import androidx.compose.material3.FilledIconButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.nova.ai.data.AppLanguage
import com.nova.ai.data.ChatMessage
import com.nova.ai.data.Role
import com.nova.ai.data.suggestions
import com.nova.ai.ui.components.GlassCard
import com.nova.ai.ui.components.NovaOrb
import com.nova.ai.ui.rememberMicPermission
import com.nova.ai.viewmodel.AssistantViewModel
import com.nova.ai.voice.VoiceState

@Composable
fun ChatScreen(vm: AssistantViewModel) {
    val messages by vm.messages.collectAsStateWithLifecycle()
    val thinking by vm.thinking.collectAsStateWithLifecycle()
    val orbState by vm.orbState.collectAsStateWithLifecycle()
    val partial by vm.voice.partial.collectAsStateWithLifecycle()
    val settings by vm.settings.collectAsStateWithLifecycle()
    val mic = rememberMicPermission()
    var input by rememberSaveable { mutableStateOf("") }
    val listState = rememberLazyListState()
    val itemCount = messages.size + (if (thinking) 1 else 0)
    val listening = orbState == VoiceState.Listening

    LaunchedEffect(itemCount) {
        if (itemCount > 0) listState.animateScrollToItem(itemCount - 1)
    }

    Column(Modifier.fillMaxSize()) {
        Box(Modifier.weight(1f).fillMaxWidth()) {
            if (messages.isEmpty()) {
                EmptyChat(settings.language) { vm.send(it) }
            } else {
                LazyColumn(
                    state = listState,
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(messages, key = { it.id }) { MessageBubble(it) }
                    if (thinking) item { TypingBubble() }
                }
            }
        }

        if (listening) {
            Text(
                partial.ifEmpty { "Listening…" },
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.primary,
                modifier = Modifier.padding(horizontal = 20.dp, vertical = 4.dp)
            )
        }

        InputBar(
            input = input,
            onInput = { input = it },
            listening = listening,
            onSend = {
                vm.send(input)
                input = ""
            },
            onMic = {
                when {
                    listening -> vm.stopListening()
                    mic.granted -> vm.startListening()
                    else -> mic.request()
                }
            }
        )
    }
}

@Composable
private fun InputBar(
    input: String,
    onInput: (String) -> Unit,
    listening: Boolean,
    onSend: () -> Unit,
    onMic: () -> Unit
) {
    val scheme = MaterialTheme.colorScheme
    Row(
        Modifier.fillMaxWidth().imePadding().padding(horizontal = 12.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        OutlinedTextField(
            value = input,
            onValueChange = onInput,
            modifier = Modifier.weight(1f),
            placeholder = { Text("Message Nova") },
            shape = RoundedCornerShape(28.dp),
            maxLines = 4,
            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
            keyboardActions = KeyboardActions(onSend = { onSend() })
        )
        Spacer(Modifier.width(8.dp))
        FilledIconButton(
            onClick = onMic,
            colors = IconButtonDefaults.filledIconButtonColors(
                containerColor = if (listening) scheme.primary else scheme.surfaceVariant,
                contentColor = if (listening) scheme.onPrimary else scheme.primary
            )
        ) {
            Icon(
                if (listening) Icons.Rounded.Stop else Icons.Rounded.Mic,
                contentDescription = if (listening) "Stop listening" else "Speak"
            )
        }
        if (input.isNotBlank()) {
            Spacer(Modifier.width(8.dp))
            FilledIconButton(onClick = onSend) {
                Icon(Icons.AutoMirrored.Rounded.Send, contentDescription = "Send")
            }
        }
    }
}

@Composable
private fun MessageBubble(message: ChatMessage) {
    val scheme = MaterialTheme.colorScheme
    val user = message.role == Role.USER
    val shape = RoundedCornerShape(
        topStart = 20.dp,
        topEnd = 20.dp,
        bottomStart = if (user) 20.dp else 4.dp,
        bottomEnd = if (user) 4.dp else 20.dp
    )
    Row(
        Modifier.fillMaxWidth(),
        horizontalArrangement = if (user) Arrangement.End else Arrangement.Start
    ) {
        Box(
            Modifier
                .widthIn(max = 320.dp)
                .clip(shape)
                .then(
                    if (user) Modifier.background(Brush.linearGradient(listOf(scheme.primary, scheme.secondary)))
                    else Modifier
                        .background(scheme.surface.copy(alpha = 0.75f))
                        .border(1.dp, scheme.outlineVariant, shape)
                )
                .padding(horizontal = 16.dp, vertical = 12.dp)
        ) {
            Text(
                message.text,
                style = MaterialTheme.typography.bodyLarge,
                color = if (user) scheme.onPrimary else scheme.onSurface
            )
        }
    }
}

@Composable
private fun TypingBubble() {
    val scheme = MaterialTheme.colorScheme
    val transition = rememberInfiniteTransition(label = "typing")
    Row(
        Modifier
            .clip(RoundedCornerShape(20.dp))
            .background(scheme.surface.copy(alpha = 0.75f))
            .padding(horizontal = 16.dp, vertical = 14.dp),
        horizontalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        repeat(3) { index ->
            val dotAlpha by transition.animateFloat(
                initialValue = 0.25f,
                targetValue = 1f,
                animationSpec = infiniteRepeatable(
                    tween(600),
                    RepeatMode.Reverse,
                    initialStartOffset = StartOffset(index * 200)
                ),
                label = "dot$index"
            )
            Box(
                Modifier
                    .size(8.dp)
                    .alpha(dotAlpha)
                    .clip(CircleShape)
                    .background(scheme.primary)
            )
        }
    }
}

@Composable
private fun EmptyChat(language: AppLanguage, onPick: (String) -> Unit) {
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        NovaOrb(orbSize = 120.dp)
        Spacer(Modifier.size(16.dp))
        Text("Ask Nova anything", style = MaterialTheme.typography.headlineMedium, textAlign = TextAlign.Center)
        Spacer(Modifier.size(8.dp))
        Text(
            "Type below, or tap the microphone to speak.",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = TextAlign.Center
        )
        Spacer(Modifier.size(20.dp))
        suggestions(language).forEach { suggestion ->
            GlassCard(Modifier.fillMaxWidth().padding(vertical = 4.dp), onClick = { onPick(suggestion) }) {
                Text(suggestion, style = MaterialTheme.typography.bodyLarge)
            }
        }
    }
}
