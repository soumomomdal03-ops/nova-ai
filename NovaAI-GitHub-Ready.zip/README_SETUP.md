# NOVA AI: Phase 1

Premium interface, onboarding, dashboard, AI chat and voice (Hindi, English, Hinglish).

## Run it on your phone (about 30 minutes the first time)

1. Install **Android Studio** (free): https://developer.android.com/studio
2. Unzip this project. In Android Studio choose **Open**, then select the `NovaAI` folder.
3. Wait for "Gradle sync" to finish (bottom bar). The first sync downloads about 1 GB and needs internet.
   If it asks to install the Android SDK or a missing platform, click **Install** and accept.
4. On your phone: Settings, About phone, tap **Build number** 7 times. Then Settings, System, Developer options, turn on **USB debugging**.
5. Plug the phone in with a USB cable and tap **Allow** on the phone.
6. In Android Studio pick your phone at the top, then press the green **Run** button.

## What to test
- Splash, onboarding (pick a language), "Continue as guest".
- Chat: type a message. Nova repeats what she heard, because the AI brain arrives in Phase 2.
- Voice: allow the microphone, hold the orb, speak, release. Nova answers aloud.
- "Start continuous conversation" keeps listening after each reply.
- Settings: theme (light/dark), language, voice choice.
- Hindi voice silent? Android Settings, search "Text-to-speech", install Hindi voice data.

## If you see red errors
Copy the full error text (or take a screenshot) and send it back. Fixing build errors comes before Phase 2.

## Project map
- `app/src/main/java/com/nova/ai/MainActivity.kt`: app entry
- `.../ui/`: theme, navigation (NovaApp, MainScaffold), components, all screens
- `.../voice/VoiceController.kt`: speech recognition and text-to-speech
- `.../viewmodel/AssistantViewModel.kt`: chat, voice and settings logic
- `.../data/`: models, saved settings, `AiProvider` (where Gemini plugs in during Phase 2)

## Get an APK file

**With a computer (easiest):** in Android Studio choose Build, Build Bundle(s) / APK(s), Build APK(s).
When it finishes, click "locate". The file is `app-debug.apk`. Copy it to your phone and open it
(allow "Install unknown apps" when asked).

**Without Android Studio (GitHub cloud build):**
1. Create a free GitHub account and a new repository.
2. Upload all files from this project, including the hidden `.github` folder.
3. Open the repository's Actions tab, choose "Build APK", press Run workflow.
4. When it turns green, open the run and download `NovaAI-debug-apk` (a zip that contains app-debug.apk).
